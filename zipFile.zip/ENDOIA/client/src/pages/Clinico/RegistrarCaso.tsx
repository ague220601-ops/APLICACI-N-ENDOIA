import ClinicoView from '@/components/ClinicoView';

export default function RegistrarCaso() {
  return <ClinicoView />;
}

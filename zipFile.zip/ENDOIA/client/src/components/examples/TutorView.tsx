import TutorView from '../TutorView';

export default function TutorViewExample() {
  return <TutorView />;
}

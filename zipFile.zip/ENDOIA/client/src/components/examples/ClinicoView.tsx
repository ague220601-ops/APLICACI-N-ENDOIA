import ClinicoView from '../ClinicoView';

export default function ClinicoViewExample() {
  return <ClinicoView />;
}
